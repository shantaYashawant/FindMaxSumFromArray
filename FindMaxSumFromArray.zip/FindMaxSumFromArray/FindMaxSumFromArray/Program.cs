﻿// See https://aka.ms/new-console-template for more information
class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Hello, World!");
        int[] arr = new int[] { -5, 60, -10, 100 };
        int sumval1 = arr[0];
        int sumval2 = sumval1;
        int n = arr.Count();
        for (int i = 1; i<n; i++)
        {
            sumval1 = Math.Max(arr[i], sumval1+arr[i]);
            sumval2 = Math.Max(sumval2, sumval1);
        }
        Console.WriteLine("Max sum of the given array is:" + sumval2);

    }
}